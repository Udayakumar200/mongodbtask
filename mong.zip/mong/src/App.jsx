
import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom';

import Employeecomp from './comp/Employeecomp'
import Headercomp from './comp/Headercomp'
import ListEmployeecomp from './comp/ListEmployeecomp'
import Viewcomp from './comp/Viewcomp';

function App() {
 

  return (
    <>
      <BrowserRouter>
        <Headercomp />
        <Routes>
          <Route path="/" element={<ListEmployeecomp />} />
          <Route path="/employees" element={<ListEmployeecomp />} />
          <Route path="/add-employee" element={<Employeecomp />} />
          <Route path="/edit-employee/:id" element={<Employeecomp />} />
          <Route path="/view-employee/:id" element={<Viewcomp />} />

        </Routes>
      </BrowserRouter>
    </>
  

  )
}

export default App

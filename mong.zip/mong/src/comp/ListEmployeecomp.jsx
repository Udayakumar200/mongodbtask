import React, { useEffect, useState } from 'react';
import { getAllEmployees, deleteEmployee } from '../services/employee';
import { useNavigate } from 'react-router-dom';

const ListEmployeecomp = () => {
    const [employees, setEmployees] = useState([]);
    const navigator = useNavigate();

    useEffect(() => {
        fetchEmployees();
    }, []);

    function fetchEmployees() {
        getAllEmployees()
            .then((response) => {
                const updatedEmployees = response.data.map(employee => ({
                    id: employee.id,
                    name: employee.employeeName,
                    location: employee.location
                }));
                setEmployees(updatedEmployees);
            })
            .catch(error => {
                console.error(error);
            });
    }

    function addNewEmployee() {
        navigator('/add-employee');
    }

    function updateEmployee(id) {
        navigator(`/edit-employee/${id}`);
    }

    function removeEmployee(id) {
        deleteEmployee(id)
            .then(() => {
                fetchEmployees();
            })
            .catch(error => {
                console.error(error);
            });
    }

    function displayEmployee(id) {
        navigator(`/view-employee/${id}`);
    }

    return (
        <div className='container'>
            <h2 className='text-center'>List of Employees</h2>
            <button type="button" className="btn btn-outline-primary mb-2" onClick={addNewEmployee}> Add Employee </button>
            <table className='table table-striped table-bordered'>
                <thead>
                    <tr>
                        <th>Employee Id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Location</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {employees.map(employee => (
                        <tr key={employee.id}>
                            <td>{employee.id}</td>
                            <td>{employee.name}</td>
                            <td>{employee.email}</td>
                            <td>{employee.location}</td>
                            <td>
                                <button className='btn btn-outline-primary' onClick={() => updateEmployee(employee.id)}>Update</button>
                                <button className="btn btn-outline-danger" onClick={() => removeEmployee(employee.id)} style={{ marginLeft: '5px' }}>Delete</button>
                                <button className="btn btn-outline-info" onClick={() => displayEmployee(employee.id)} style={{ marginLeft: '5px' }}>View</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ListEmployeecomp;

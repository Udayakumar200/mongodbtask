
import React, { useEffect, useState } from 'react';
import { createEmployee, getEmployee, updateEmployee } from '../services/employee';
import { useNavigate, useParams } from 'react-router-dom';

const Employeecomp = () => {
    const { id: routeId } = useParams();
    const [id, setId] = useState(routeId || '');
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [location, setLocation] = useState('');
    const [errors, setErrors] = useState({
        id: '',
        name: '',
        email: '',
        location: ''
    });
    const navigator = useNavigate();

    useEffect(() => {
        if (routeId) {
            getEmployee(routeId)
                .then((response) => {
                    setName(response.data.name);
                    setEmail(response.data.email);
                    setLocation(response.data.location);
                })
                .catch((error) => {
                    console.error(error);
                });
        }
    }, [routeId]);

    function saveOrUpdateEmployee(e) {
        e.preventDefault();

        if (validateForm()) {
            const employee = { name, email, location };

            if (id) {
                updateEmployee(id, employee)
                    .then((response) => {
                        console.log(response.data);
                        navigator('/employees');
                    })
                    .catch((error) => {
                        console.error(error);
                    });
            } else {
                createEmployee(employee)
                    .then((response) => {
                        console.log(response.data);
                        navigator('/employees');
                    })
                    .catch((error) => {
                        console.error(error);
                    });
            }
        }
    }

    function validateForm() {
        let valid = true;
        const errorsCopy = { ...errors };

        if (!id.trim()) {
            errorsCopy.id = 'Employee ID is required';
            valid = false;
        } else {
            errorsCopy.id = '';
        }

        if (!name.trim()) {
            errorsCopy.name = 'Employee name is required';
            valid = false;
        } else {
            errorsCopy.name = '';
        }

        if (!email.trim()) {
            errorsCopy.email = 'Email is required';
            valid = false;
        } else {
            errorsCopy.email = '';
        }

        if (!location.trim()) {
            errorsCopy.location = 'Location is required';
            valid = false;
        } else {
            errorsCopy.location = '';
        }

        setErrors(errorsCopy);
        return valid;
    }

    return (
        <div className='container'>
            <br /> <br />
            <div className='row'>
                <div className='card col-md-6 col-offset-md-3'>
                    <h2 className='text-center'>{routeId ? 'Update Employee' : 'Add Employee'}</h2>
                    <div className='card-body'>
                        <form>
                            <div className='form-group mb-3'>
                                <label className='form-label'>Employee ID:</label>
                                <input
                                    type='text'
                                    placeholder='Enter Employee ID'
                                    value={id}
                                    className={`form-control ${errors.id ? 'is-invalid' : ''}`}
                                    onChange={(e) => setId(e.target.value)}
                                />
                                {errors.id && <div className='invalid-feedback'>{errors.id}</div>}
                            </div>
                            <div className='form-group mb-3'>
                                <label className='form-label'>Employee Name:</label>
                                <input
                                    type='text'
                                    placeholder='Enter Employee Name'
                                    value={name}
                                    className={`form-control ${errors.name ? 'is-invalid' : ''}`}
                                    onChange={(e) => setName(e.target.value)}
                                />
                                {errors.name && <div className='invalid-feedback'>{errors.name}</div>}
                            </div>
                            <div className='form-group mb-3'>
                                <label className='form-label'>Email:</label>
                                <input
                                    type='text'
                                    placeholder='Enter Employee Email'
                                    value={email}
                                    className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                                    onChange={(e) => setEmail(e.target.value)}
                                />
                                {errors.email && <div className='invalid-feedback'>{errors.email}</div>}
                            </div>
                            <div className='form-group mb-3'>
                                <label className='form-label'>Location:</label>
                                <input
                                    type='text'
                                    placeholder='Enter Employee Location'
                                    value={location}
                                    className={`form-control ${errors.location ? 'is-invalid' : ''}`}
                                    onChange={(e) => setLocation(e.target.value)}
                                />
                                {errors.location && <div className='invalid-feedback'>{errors.location}</div>}
                            </div>
                            <button className='btn btn-success' onClick={saveOrUpdateEmployee}>
                                Submit
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Employeecomp;

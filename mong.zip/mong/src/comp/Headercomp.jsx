import React from 'react'

const Headercomp = () => {
  return (
    <div>  
    <header>
<nav className="navbar navbar-dark bg-primary">
<a className="navbar-brand " href="http://www.google.com">Employee Management</a>
</nav>
</header>
</div>
  )
}

export default Headercomp